$(".al").click(function(){
	$(".none").show();
})
$(".all").click(function(){
	$(".none1").show();
})
