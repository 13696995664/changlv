var app = new Vue({
	el: '#app',
	data: {
		a: true,
		s: true,
		d: true,
		f: true
	},
	methods:{
		q: function() {
			this.a = false;
		},
		w: function() {
			this.a = true;
			this.d = true;
			this.f = true;
		},
		e: function() {
			this.s = false;
		},
		r: function() {
			this.s = true;
		},
		t: function() {
			this.d = false;
			this.a = false;
			this.s = false;
		},
		y: function() {
			this.d = true;
		},
		u: function() {
			this.f = false;
		},
		i: function() {
			this.f = true;
		}
	}
})