var app = new Vue({
	el: '#app',
	data: {
		a: false,
		shows: false,
		shows1: false,
		shows2: false,
		price:268,
		allprice:0,
		allshows:false,
		Pronum:3,
		num:1,
		choose:0,
		choose1:0,
		choose2:0,
		color:"白色",
		color1:"黑色",
		color2:"绿色",
		type:38,
		type1:39,
		type2:40,
		type3:41,
		type4:42,
		type5:43,
		typeChoose:0
	},
	methods: {
		b: function() {
			this.a = true;
		},
		c: function() {
			this.a = false;
		},
		Btnon:function() {
			this.shows = false;
			this.allprice = this.allprice - this.price * this.num;
			this.choose = 0;
		},
		Btnoff:function() {
			this.shows = true;
			this.allprice = this.allprice + this.price * this.num;
			this.choose = 1;
			if(this.choose == 1 && this.choose1 == 1 && this.choose2 == 1){
				this.allshows = true;
			}
		},
		Btnon1:function() {
			this.shows1 = false;
			this.allprice = this.allprice - this.price;
		},
		Btnoff1:function() {
			this.shows1 = true;
			this.allprice = this.allprice + this.price;
			this.choose1 = 1;
		},
		Btnon2:function() {
			this.shows2 = false;
			this.allprice = this.allprice - this.price;
			
		},
		Btnoff2:function() {
			this.shows2 = true;
			this.allprice = this.allprice + this.price;
			this.choose2 = 1;
		},
		allBtnon:function(){
			this.allshows = false;
			this.shows = false;
			this.shows1 = false;
			this.shows2 = false;
			this.allprice = this.allprice - this.price * this.Pronum;
			
		},
		allBtnoff:function(){
			this.allshows = true;
			this.shows = true;
			this.shows1 = true;
			this.shows2 = true;
			this.allprice = this.price * this.Pronum;
		},
		reduce:function(){
			if(this.num < 2){
				return false;
			}else{
				this.num = this.num - 1;
				if(this.choose == 1){
					this.allprice =this.allprice - this.price;
				}
			}
		},
		add:function(){
			this.num = this.num + 1;
			if(this.choose == 1){
				this.allprice = this.allprice + this.price;
			}
		},
		Distype:function(){
			if(this.typeChoose == 0){
				document.getElementById("choose").style.background = "red";
				this.typeChoose = 1;	
			}else{
				document.getElementById("choose").style.background = "white";
				this.typeChoose = 0;	
			}
			
		}
	}
})
//$(".commodity-right-zhong").click(function(){
//	$(".delete span").animate({"right":"0%"},500)
//	$(".commodity1").animate({"right":"16%"},500)
//})
//$(".commodity-right-xia-left").click(function(){
//	$(".delete span").animate({"right":"-16%"},500)
//	$(".commodity1").animate({"right":"0%"},500)
//})