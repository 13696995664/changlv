var app = new Vue({
	el: "#apps",
	data: {
		show: false
	},
	methods: {
		on: function() {
			this.show = true;
		},
		of: function() {
			this.show = false;
		}
	}
})