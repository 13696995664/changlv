var app = new Vue({
	el: '#apps',
	data: {
		show: false,
		a:'请选择'
	},
	methods: {
		on: function() {
			this.show = true;
		},
		off1: function(){
			this.show = false;
			this.a= '中国建设银行';
		},
		off2: function(){
			this.show = false;
			this.a= '中国银行';
		},
		off3: function(){
			this.show = false;
			this.a= '中国工商银行';
		},
		off4: function(){
			this.show = false;
			this.a= '中国农业银行';
		},
		off5: function(){
			this.show = false;
			this.a= '招商银行';
		},
		off6: function(){
			this.show = false;
			this.a= '泉州银行';
		},
		off8: function(){
			this.show = false;
			this.a= '厦门银行';
		},
	}
})