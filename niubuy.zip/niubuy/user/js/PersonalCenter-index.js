var a = new Vue({
	el: '#app',
	data: {
		show: false,
		b: '男'
	},
	methods: {
		Choice: function() {
			this.show = true;
		},
		boy: function() {
			this.show = false;
			this.b = '男'
		},
		girl: function() {
			this.show = false;
			this.b = '女'
		},
		secrecy: function() {
			this.show = false;
			this.b = '保密'
		}
	}
})