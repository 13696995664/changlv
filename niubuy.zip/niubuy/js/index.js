//@media screen and (min-width:1600px) {
//	scan {
//		font-size: 36px;
//	}
//}

var a = document.getElementById("head").Width();
if (a > 648){
	document.getElementById("head").height("800px");
}
