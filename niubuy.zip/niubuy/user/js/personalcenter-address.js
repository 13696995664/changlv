var app = new Vue({
	el: "#app",
	data: {
		a: false,
		e:true
	},
	methods: {
		b: function() {
			this.a = true;
		},
		c: function(){
			this.a = false;
		},
		t: function(){
			this.e = false;
		},
		y: function(){
			this.e = true;
		}
	}
})