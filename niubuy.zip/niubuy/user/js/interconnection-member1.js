var app = new Vue({
	el: "#app",
	data: {
		a: false
	},
	methods: {
		b: function() {
			this.a = true;
		},
		d: function(){
			this.a = false;
		}
	}
})