var app = new Vue({
	el: '#app',
	data: {
		Firstword:'',
		Firstword1:'',
		Firstword2:'',
		Firstword3:'',
		Firstword4:'',
		Firstword5:''
	},
	methods: {

	},
	watch:{
		Firstword:function(){
			two.focus();
		},
		Firstword1:function(){
			three.focus();
		},
		Firstword2:function(){
			four.focus();
			price();
			whragthet : function(){
				alerty("1");
			}
		},
		Firstword3:function(){
			five.focus();
		},
		Firstword4:function(){
			six.focus();
		}
	}
})