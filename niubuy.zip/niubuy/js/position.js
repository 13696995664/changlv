// 百度地图API功能
getLocation();
function getLocation() {
	var map = new BMap.Map("allmap");
	var point = new BMap.Point(116.331398, 39.897445);
	map.centerAndZoom(point, 12);

	var geolocation = new BMap.Geolocation();
	geolocation.getCurrentPosition(function(r) {
		if(this.getStatus() == BMAP_STATUS_SUCCESS) {
			var mk = new BMap.Marker(r.point);
			map.addOverlay(mk);
			map.panTo(r.point);
			j = r.point.lng;
			w = r.point.lat;
			a();
		} else {
			alert('failed' + this.getStatus());
		}
	}, {
		enableHighAccuracy: true
	})
}
// 百度地图API功能
function a() {
	var map = new BMap.Map("allmap");
	var point = new BMap.Point(j, w);
	map.centerAndZoom(point, 12);
	var geoc = new BMap.Geocoder();
	var pt = point;
	geoc.getLocation(pt, function(rs) {
		var addComp = rs.addressComponents;
		$(".city").html(addComp.province + ", " + addComp.city + ", " + addComp.district);
	});
}