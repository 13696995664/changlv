//var b = new Vue({
//	el: '#jump',
//	data: {
//		:false,
//	},
//	methods: function(){
//		this
//	}
//})

var hide = new Vue({
	el: '#hide',
	data: {
		yes: false, 
	},
	methods: {
		show: function() {
			this.yes = true;
		}
	}
})